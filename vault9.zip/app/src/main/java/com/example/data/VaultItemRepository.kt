package com.example.data

import kotlinx.coroutines.flow.Flow

class VaultItemRepository(private val vaultItemDao: VaultItemDao) {
    val allItems: Flow<List<VaultItem>> = vaultItemDao.getAllItems()
    val favoriteItems: Flow<List<VaultItem>> = vaultItemDao.getFavoriteItems()
    val archivedItems: Flow<List<VaultItem>> = vaultItemDao.getArchivedItems()
    val deletedItems: Flow<List<VaultItem>> = vaultItemDao.getDeletedItems()

    fun getRecentItems(limit: Int): Flow<List<VaultItem>> = vaultItemDao.getRecentItems(limit)

    suspend fun getItemById(id: Int): VaultItem? = vaultItemDao.getItemById(id)

    suspend fun insertItem(item: VaultItem): Long = vaultItemDao.insertItem(item)

    suspend fun updateItem(item: VaultItem) = vaultItemDao.updateItem(item)

    suspend fun deleteItem(item: VaultItem) = vaultItemDao.deleteItem(item)

    suspend fun emptyTrash() = vaultItemDao.emptyTrash()
}
