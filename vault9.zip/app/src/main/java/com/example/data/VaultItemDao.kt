package com.example.data

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.OnConflictStrategy
import androidx.room.Query
import androidx.room.Update
import kotlinx.coroutines.flow.Flow

@Dao
interface VaultItemDao {
    @Query("SELECT * FROM vault_items WHERE isDeleted = 0 AND isArchived = 0 ORDER BY pinned DESC, updatedAt DESC")
    fun getAllItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE isFavorite = 1 AND isDeleted = 0 AND isArchived = 0 ORDER BY updatedAt DESC")
    fun getFavoriteItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE isArchived = 1 AND isDeleted = 0 ORDER BY updatedAt DESC")
    fun getArchivedItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE isDeleted = 1 ORDER BY updatedAt DESC")
    fun getDeletedItems(): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE isDeleted = 0 AND isArchived = 0 ORDER BY updatedAt DESC LIMIT :limit")
    fun getRecentItems(limit: Int): Flow<List<VaultItem>>

    @Query("SELECT * FROM vault_items WHERE id = :id")
    suspend fun getItemById(id: Int): VaultItem?

    @Insert(onConflict = OnConflictStrategy.REPLACE)
    suspend fun insertItem(item: VaultItem): Long

    @Update
    suspend fun updateItem(item: VaultItem)

    @Delete
    suspend fun deleteItem(item: VaultItem)

    @Query("DELETE FROM vault_items WHERE isDeleted = 1")
    suspend fun emptyTrash()
}
