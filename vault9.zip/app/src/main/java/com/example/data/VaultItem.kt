package com.example.data

import androidx.room.Entity
import androidx.room.PrimaryKey

@Entity(tableName = "vault_items")
data class VaultItem(
    @PrimaryKey(autoGenerate = true) val id: Int = 0,
    val category: String, // password, note, card, document, identity, bank_account, crypto, license, wifi, api, custom
    val title: String,
    val subtitle: String = "",
    val encryptedData: String, // Encrypted GCM Payload JSON
    val iv: String, // IV used for decryption
    val isFavorite: Boolean = false,
    val isArchived: Boolean = false,
    val isDeleted: Boolean = false, // Trash bin
    val createdAt: Long = System.currentTimeMillis(),
    val updatedAt: Long = System.currentTimeMillis(),
    val folder: String? = null,
    val tags: String = "", // Comma-separated tags
    val pinned: Boolean = false
)
