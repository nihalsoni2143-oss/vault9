package com.example

import android.os.Bundle
import android.view.WindowManager
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.lifecycle.ViewModelProvider
import com.example.ui.Vault9App
import com.example.ui.VaultViewModel
import com.example.ui.theme.MyApplicationTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        
        // NOTE: FLAG_SECURE prevents screen captures and video recordings.
        // In the AI Studio streaming emulator, this causes the screen to appear completely black or blank.
        // We comment it out for development and preview purposes, but it can be safely re-enabled for physical/production releases.
        /*
        window.setFlags(
            WindowManager.LayoutParams.FLAG_SECURE,
            WindowManager.LayoutParams.FLAG_SECURE
        )
        */

        enableEdgeToEdge()

        // Instantiate AndroidViewModel
        val viewModel = ViewModelProvider(this)[VaultViewModel::class.java]

        setContent {
            MyApplicationTheme {
                Vault9App(viewModel)
            }
        }
    }

    override fun onStop() {
        super.onStop()
        // Lock the vault immediately when the app goes into background for maximum defense
        try {
            val viewModel = ViewModelProvider(this)[VaultViewModel::class.java]
            viewModel.lock()
        } catch (e: Exception) {
            // Safe fallback
        }
    }
}
