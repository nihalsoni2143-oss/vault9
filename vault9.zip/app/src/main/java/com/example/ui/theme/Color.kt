package com.example.ui.theme

import androidx.compose.ui.graphics.Color

// Light Theme Palette
val PureWhite = Color(0xFFFFFFFF)
val SurfaceGray = Color(0xFFF7F7F7)
val CardBorderGray = Color(0xFFECECEC)
val PrimaryBlue = Color(0xFF1E3A8A) // Slate Deep Blue
val SecondaryBlue = Color(0xFF3B82F6) // Electric Accent Blue
val TextPrimary = Color(0xFF111111)
val TextSecondary = Color(0xFF6B7280)

// Dark Theme Palette
val PureDark = Color(0xFF121212)
val SurfaceDark = Color(0xFF1E1E1E)
val CardBorderDark = Color(0xFF2C2C2C)
val PrimaryBlueDark = Color(0xFF60A5FA)
val SecondaryBlueDark = Color(0xFF93C5FD)
val TextPrimaryDark = Color(0xFFF3F4F6)
val TextSecondaryDark = Color(0xFF9CA3AF)

// Semantic Colors
val SuccessGreen = Color(0xFF22C55E)
val ErrorRed = Color(0xFFEF4444)
val WarningYellow = Color(0xFFF59E0B)

// Core Purple / Pink fallback constants for app compatibility
val Purple80 = Color(0xFFD0BCFF)
val PurpleGrey80 = Color(0xFFCCC2DC)
val Pink80 = Color(0xFFEFB8C8)
val Purple40 = Color(0xFF6650a4)
val PurpleGrey40 = Color(0xFF625b71)
val Pink40 = Color(0xFF7D5260)
