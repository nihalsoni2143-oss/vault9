package com.example.ui

import android.content.Context
import android.widget.Toast
import androidx.activity.compose.BackHandler
import androidx.compose.animation.AnimatedVisibility
import androidx.compose.animation.animateColorAsState
import androidx.compose.animation.animateContentSize
import androidx.compose.animation.core.animateFloatAsState
import androidx.compose.animation.core.tween
import androidx.compose.foundation.Canvas
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable
import androidx.compose.foundation.interaction.MutableInteractionSource
import androidx.compose.foundation.layout.Arrangement
import androidx.compose.foundation.layout.Box
import androidx.compose.foundation.layout.Column
import androidx.compose.foundation.layout.Row
import androidx.compose.foundation.layout.Spacer
import androidx.compose.foundation.layout.fillMaxSize
import androidx.compose.foundation.layout.fillMaxWidth
import androidx.compose.foundation.layout.height
import androidx.compose.foundation.layout.navigationBarsPadding
import androidx.compose.foundation.layout.padding
import androidx.compose.foundation.layout.size
import androidx.compose.foundation.layout.statusBarsPadding
import androidx.compose.foundation.layout.width
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.grid.GridCells
import androidx.compose.foundation.lazy.grid.LazyVerticalGrid
import androidx.compose.foundation.lazy.grid.items
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.CircleShape
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.AccountCircle
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.ArrowBack
import androidx.compose.material.icons.filled.Build
import androidx.compose.material.icons.filled.Check
import androidx.compose.material.icons.filled.Close
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Favorite
import androidx.compose.material.icons.filled.FavoriteBorder
import androidx.compose.material.icons.filled.Home
import androidx.compose.material.icons.filled.Info
import androidx.compose.material.icons.filled.List
import androidx.compose.material.icons.filled.Lock
import androidx.compose.material.icons.filled.Person
import androidx.compose.material.icons.filled.Refresh
import androidx.compose.material.icons.filled.Search
import androidx.compose.material.icons.filled.Settings
import androidx.compose.material.icons.filled.Star
import androidx.compose.material.icons.filled.Warning
import androidx.compose.material3.Button
import androidx.compose.material3.ButtonDefaults
import androidx.compose.material3.Card
import androidx.compose.material3.CardDefaults
import androidx.compose.material3.Checkbox
import androidx.compose.material3.Divider
import androidx.compose.material3.ExperimentalMaterial3Api
import androidx.compose.material3.FloatingActionButton
import androidx.compose.material3.Icon
import androidx.compose.material3.IconButton
import androidx.compose.material3.MaterialTheme
import androidx.compose.material3.NavigationBar
import androidx.compose.material3.NavigationBarItem
import androidx.compose.material3.NavigationBarItemDefaults
import androidx.compose.material3.OutlinedButton
import androidx.compose.material3.OutlinedTextField
import androidx.compose.material3.OutlinedTextFieldDefaults
import androidx.compose.material3.Scaffold
import androidx.compose.material3.Slider
import androidx.compose.material3.SliderDefaults
import androidx.compose.material3.Switch
import androidx.compose.material3.SwitchDefaults
import androidx.compose.material3.Text
import androidx.compose.material3.TopAppBar
import androidx.compose.material3.TopAppBarDefaults
import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.compose.runtime.collectAsState
import androidx.compose.runtime.getValue
import androidx.compose.runtime.mutableIntStateOf
import androidx.compose.runtime.mutableStateListOf
import androidx.compose.runtime.mutableStateMapOf
import androidx.compose.runtime.mutableStateOf
import androidx.compose.runtime.remember
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.draw.clip
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.graphics.StrokeCap
import androidx.compose.ui.graphics.drawscope.Stroke
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.platform.testTag
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.text.input.PasswordVisualTransformation
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.style.TextOverflow
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.security.UnlockResult
import com.example.ui.theme.SuccessGreen
import com.example.ui.theme.ErrorRed
import com.example.ui.theme.WarningYellow
import kotlinx.coroutines.delay
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

sealed class Screen {
    object Unlock : Screen()
    object SetupPin : Screen()
    object Main : Screen()
    data class AddEdit(val category: String, val itemId: Int? = null) : Screen()
    data class Detail(val itemId: Int) : Screen()
    object IntruderLogs : Screen()
}

@Composable
fun Vault9App(viewModel: VaultViewModel) {
    val context = LocalContext.current
    val hasPin by viewModel.hasPin.collectAsState()
    val isUnlocked by viewModel.isUnlocked.collectAsState()

    val backstack = remember { mutableStateListOf<Screen>() }

    LaunchedEffect(hasPin, isUnlocked) {
        if (backstack.isEmpty()) {
            if (!hasPin) {
                backstack.add(Screen.SetupPin)
            } else {
                backstack.add(Screen.Unlock)
            }
        } else {
            if (hasPin && !isUnlocked && backstack.last() !is Screen.Unlock) {
                backstack.clear()
                backstack.add(Screen.Unlock)
            } else if (hasPin && isUnlocked && backstack.last() is Screen.Unlock) {
                backstack.clear()
                backstack.add(Screen.Main)
            }
        }
    }

    val currentScreen = backstack.lastOrNull() ?: Screen.Unlock

    BackHandler(enabled = backstack.size > 1) {
        backstack.removeAt(backstack.lastIndex)
    }

    val navigateTo: (Screen) -> Unit = { screen ->
        backstack.add(screen)
    }

    val navigateBack: () -> Unit = {
        if (backstack.size > 1) {
            backstack.removeAt(backstack.lastIndex)
        }
    }

    val resetToScreen: (Screen) -> Unit = { screen ->
        backstack.clear()
        backstack.add(screen)
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .clickable(
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            ) {
                viewModel.userActivityDetected()
            }
    ) {
        when (currentScreen) {
            is Screen.Unlock -> UnlockScreen(viewModel, onUnlockSuccess = { isFake ->
                viewModel.userActivityDetected()
                resetToScreen(Screen.Main)
                val msg = if (isFake) "Secondary Decryption Wallet Loaded" else "Master Vault Decrypted"
                Toast.makeText(context, msg, Toast.LENGTH_SHORT).show()
            })
            is Screen.SetupPin -> SetupPinScreen(viewModel, onSetupSuccess = {
                viewModel.userActivityDetected()
                resetToScreen(Screen.Main)
                Toast.makeText(context, "Secure Vault Configured Successfully", Toast.LENGTH_LONG).show()
            })
            is Screen.Main -> MainDashboard(viewModel, navigateTo)
            is Screen.AddEdit -> AddEditScreen(viewModel, category = currentScreen.category, itemId = currentScreen.itemId, onNavigateBack = navigateBack)
            is Screen.Detail -> DetailScreen(viewModel, itemId = currentScreen.itemId, onNavigateBack = navigateBack, onEditClick = { id, cat ->
                navigateTo(Screen.AddEdit(category = cat, itemId = id))
            })
            is Screen.IntruderLogs -> IntruderLogsScreen(viewModel, onNavigateBack = navigateBack)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SetupPinScreen(viewModel: VaultViewModel, onSetupSuccess: () -> Unit) {
    var pin by remember { mutableStateOf("") }
    var confirmPin by remember { mutableStateOf("") }
    var secondaryPin by remember { mutableStateOf("") }
    var step by remember { mutableIntStateOf(1) }
    var errorMsg by remember { mutableStateOf<String?>(null) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Setup Vault9 Security", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground) },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(padding)
                .padding(24.dp),
            horizontalAlignment = Alignment.CenterHorizontally,
            verticalArrangement = Arrangement.Center
        ) {
            Icon(
                imageVector = Icons.Default.Lock,
                contentDescription = "Shield Security Logo",
                tint = MaterialTheme.colorScheme.primary,
                modifier = Modifier
                    .size(80.dp)
                    .padding(bottom = 16.dp)
            )

            Text(
                text = if (step == 1) "Create Master PIN" else "Configure Secondary PIN (Fake Vault)",
                style = MaterialTheme.typography.headlineSmall,
                fontWeight = FontWeight.Bold,
                textAlign = TextAlign.Center,
                color = MaterialTheme.colorScheme.onBackground
            )

            Text(
                text = if (step == 1) 
                    "Establish a 4 or 6-digit cryptographic PIN to encrypt and lock your private databases offline." 
                    else "Enter a separate fake PIN. Entering this PIN will open a fake empty vault context for plausible deniability.",
                style = MaterialTheme.typography.bodyMedium,
                color = MaterialTheme.colorScheme.onSurfaceVariant,
                textAlign = TextAlign.Center,
                modifier = Modifier.padding(vertical = 12.dp, horizontal = 16.dp)
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (step == 1) {
                OutlinedTextField(
                    value = pin,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) pin = it },
                    label = { Text("Master PIN (4-6 digits)") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth().testTag("master_pin_input"),
                    colors = OutlinedTextFieldDefaults.colors()
                )

                Spacer(modifier = Modifier.height(12.dp))

                OutlinedTextField(
                    value = confirmPin,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) confirmPin = it },
                    label = { Text("Confirm Master PIN") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth().testTag("confirm_pin_input"),
                    colors = OutlinedTextFieldDefaults.colors()
                )
            } else {
                OutlinedTextField(
                    value = secondaryPin,
                    onValueChange = { if (it.length <= 6 && it.all { c -> c.isDigit() }) secondaryPin = it },
                    label = { Text("Secondary PIN (Optional)") },
                    visualTransformation = PasswordVisualTransformation(),
                    keyboardOptions = KeyboardOptions(keyboardType = KeyboardType.NumberPassword),
                    modifier = Modifier.fillMaxWidth().testTag("secondary_pin_input"),
                    colors = OutlinedTextFieldDefaults.colors()
                )
            }

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 12.dp)
                )
            }

            Spacer(modifier = Modifier.height(32.dp))

            Button(
                onClick = {
                    errorMsg = null
                    if (step == 1) {
                        if (pin.length < 4) {
                            errorMsg = "PIN must contain at least 4 digits."
                        } else if (pin != confirmPin) {
                            errorMsg = "PINs do not match. Please verify again."
                        } else {
                            val ok = viewModel.setupMasterPin(pin)
                            if (ok) {
                                step = 2
                            } else {
                                errorMsg = "Failed to initialize secure keystore."
                            }
                        }
                    } else {
                        if (secondaryPin.isNotEmpty()) {
                            if (secondaryPin.length < 4) {
                                errorMsg = "Secondary PIN must contain at least 4 digits."
                                return@Button
                            } else if (secondaryPin == pin) {
                                errorMsg = "Secondary PIN cannot be the same as your Master PIN."
                                return@Button
                            } else {
                                viewModel.setupFakePin(secondaryPin)
                            }
                        }
                        onSetupSuccess()
                    }
                },
                modifier = Modifier
                    .fillMaxWidth()
                    .height(52.dp)
                    .testTag("setup_next_button"),
                shape = RoundedCornerShape(12.dp),
                colors = ButtonDefaults.buttonColors(containerColor = MaterialTheme.colorScheme.primary)
            ) {
                Text(
                    text = if (step == 1) "Initialize Vault" else if (secondaryPin.isEmpty()) "Skip & Complete Setup" else "Set Fake Wallet & Complete",
                    fontWeight = FontWeight.Bold,
                    fontSize = 16.sp,
                    color = MaterialTheme.colorScheme.background
                )
            }
        }
    }
}

@Composable
fun UnlockScreen(viewModel: VaultViewModel, onUnlockSuccess: (isFake: Boolean) -> Unit) {
    var pin by remember { mutableStateOf("") }
    var errorMsg by remember { mutableStateOf<String?>(null) }
    val isBruteForceLocked by viewModel.isBruteForceLocked.collectAsState()
    val cooldownSeconds by viewModel.bruteForceCooldown.collectAsState()
    val isBiometricEnabled = viewModel.isBiometricEnabled()
    val securityWarning by viewModel.securityWarning.collectAsState()

    LaunchedEffect(Unit) {
        if (isBiometricEnabled && !isBruteForceLocked) {
            val success = viewModel.unlockWithBiometrics()
            if (success) {
                onUnlockSuccess(false)
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .statusBarsPadding()
            .navigationBarsPadding()
            .padding(24.dp),
        horizontalAlignment = Alignment.CenterHorizontally,
        verticalArrangement = Arrangement.SpaceBetween
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = "VAULT9",
                style = MaterialTheme.typography.displaySmall,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.primary,
                letterSpacing = 4.sp
            )
            Text(
                text = "Your Private Digital Vault",
                style = MaterialTheme.typography.labelLarge,
                color = MaterialTheme.colorScheme.secondary,
                fontWeight = FontWeight.Medium
            )

            if (securityWarning != null) {
                Card(
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.2f)),
                    shape = RoundedCornerShape(12.dp),
                    modifier = Modifier
                        .padding(top = 16.dp)
                        .fillMaxWidth()
                ) {
                    Row(
                        modifier = Modifier.padding(12.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Warning,
                            contentDescription = "Alert",
                            tint = MaterialTheme.colorScheme.error,
                            modifier = Modifier.size(24.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = securityWarning!!,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.error,
                            fontWeight = FontWeight.Medium
                        )
                    }
                }
            }
        }

        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Text(
                text = if (isBruteForceLocked) "Brute Force Protection Active" else "Enter Master PIN",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = if (isBruteForceLocked) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.onBackground
            )

            Spacer(modifier = Modifier.height(16.dp))

            if (isBruteForceLocked) {
                Text(
                    text = "Cooldown active. Try again in $cooldownSeconds seconds.",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.error,
                    fontWeight = FontWeight.SemiBold
                )
            } else {
                Row(
                    horizontalArrangement = Arrangement.Center,
                    verticalAlignment = Alignment.CenterVertically,
                    modifier = Modifier.height(40.dp)
                ) {
                    val maxDots = maxOf(6, pin.length)
                    for (i in 0 until maxDots) {
                        val active = i < pin.length
                        val size by animateFloatAsState(targetValue = if (active) 16f else 12f)
                        val color by animateColorAsState(targetValue = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.outline)

                        Box(
                            modifier = Modifier
                                .padding(8.dp)
                                .size(size.dp)
                                .clip(CircleShape)
                                .background(color)
                        )
                    }
                }
            }

            if (errorMsg != null) {
                Text(
                    text = errorMsg!!,
                    color = MaterialTheme.colorScheme.error,
                    style = MaterialTheme.typography.bodySmall,
                    modifier = Modifier.padding(top = 12.dp),
                    fontWeight = FontWeight.SemiBold
                )
            }
        }

        Column(
            modifier = Modifier.fillMaxWidth(),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            val keys = listOf(
                listOf("1", "2", "3"),
                listOf("4", "5", "6"),
                listOf("7", "8", "9"),
                listOf("Clear", "0", "Delete")
            )

            keys.forEach { row ->
                Row(
                    modifier = Modifier.fillMaxWidth(),
                    horizontalArrangement = Arrangement.SpaceEvenly
                ) {
                    row.forEach { key ->
                        Box(
                            modifier = Modifier
                                .size(75.dp)
                                .clip(CircleShape)
                                .clickable {
                                    if (isBruteForceLocked) return@clickable
                                    errorMsg = null
                                    when (key) {
                                        "Clear" -> pin = ""
                                        "Delete" -> if (pin.isNotEmpty()) pin = pin.dropLast(1)
                                        else -> {
                                            if (pin.length < 6) {
                                                pin += key
                                                if (pin.length >= 4) {
                                                    val res = viewModel.unlockWithPin(pin)
                                                    if (res == UnlockResult.SUCCESS) {
                                                        onUnlockSuccess(false)
                                                    } else if (res == UnlockResult.SUCCESS_FAKE) {
                                                        onUnlockSuccess(true)
                                                    } else if (pin.length == 6 && res == UnlockResult.FAILED) {
                                                        errorMsg = "Invalid decryption PIN attempt."
                                                        pin = ""
                                                    }
                                                }
                                            }
                                        }
                                    }
                                }
                                .testTag("key_$key"),
                            contentAlignment = Alignment.Center
                        ) {
                            if (key == "Clear" || key == "Delete") {
                                Text(
                                    text = key,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.secondary
                                )
                            } else {
                                Text(
                                    text = key,
                                    style = MaterialTheme.typography.headlineMedium,
                                    fontWeight = FontWeight.SemiBold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                            }
                        }
                    }
                }
            }

            Spacer(modifier = Modifier.height(12.dp))

            if (isBiometricEnabled && !isBruteForceLocked) {
                IconButton(
                    onClick = {
                        val success = viewModel.unlockWithBiometrics()
                        if (success) onUnlockSuccess(false)
                    },
                    modifier = Modifier.size(56.dp).testTag("biometric_login_button")
                ) {
                    Icon(
                        imageVector = Icons.Default.Person,
                        contentDescription = "Scan Fingerprint",
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(40.dp)
                    )
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainDashboard(viewModel: VaultViewModel, onNavigate: (Screen) -> Unit) {
    var currentTab by remember { mutableStateOf("home") }

    Scaffold(
        bottomBar = {
            Column {
                Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 1.dp)
                NavigationBar(
                    containerColor = MaterialTheme.colorScheme.background,
                    tonalElevation = 0.dp,
                    modifier = Modifier.navigationBarsPadding()
                ) {
                    val tabs = listOf(
                        Triple("home", "Home", Icons.Default.Home),
                        Triple("vault", "Vault", Icons.Default.Lock),
                        Triple("search", "Search", Icons.Default.Search),
                        Triple("settings", "Settings", Icons.Default.Settings)
                    )

                    tabs.forEach { (tabId, label, icon) ->
                        val selected = currentTab == tabId
                        NavigationBarItem(
                            selected = selected,
                            onClick = { currentTab = tabId },
                            icon = { Icon(imageVector = icon, contentDescription = label) },
                            label = { Text(text = label, fontWeight = FontWeight.Bold) },
                            colors = NavigationBarItemDefaults.colors(
                                selectedIconColor = MaterialTheme.colorScheme.primary,
                                selectedTextColor = MaterialTheme.colorScheme.primary,
                                unselectedIconColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                unselectedTextColor = MaterialTheme.colorScheme.onSurfaceVariant,
                                indicatorColor = MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.4f)
                            ),
                            modifier = Modifier.testTag("tab_$tabId")
                        )
                    }
                }
            }
        },
        floatingActionButton = {
            if (currentTab == "home" || currentTab == "vault") {
                FloatingActionButton(
                    onClick = {
                        onNavigate(Screen.AddEdit(category = "password"))
                    },
                    containerColor = MaterialTheme.colorScheme.primary,
                    contentColor = MaterialTheme.colorScheme.background,
                    shape = RoundedCornerShape(16.dp),
                    modifier = Modifier.testTag("fab_quick_add")
                ) {
                    Icon(imageVector = Icons.Default.Add, contentDescription = "Create New Vault Item")
                }
            }
        }
    ) { innerPadding ->
        Box(
            modifier = Modifier
                .fillMaxSize()
                .padding(innerPadding)
        ) {
            when (currentTab) {
                "home" -> HomeScreen(viewModel, onNavigate)
                "vault" -> VaultScreen(viewModel, onNavigate)
                "search" -> SearchScreen(viewModel, onNavigate)
                "settings" -> SettingsScreen(viewModel, onNavigate)
            }
        }
    }
}

@Composable
fun HomeScreen(viewModel: VaultViewModel, onNavigate: (Screen) -> Unit) {
    val stats by viewModel.dashboardStats.collectAsState()
    val favorites by viewModel.favoriteItems.collectAsState()
    val isFakeVault by viewModel.isFakeVault.collectAsState()

    val recentItemsState = viewModel.getRecentItems(3).collectAsState(emptyList())
    val recentItems = recentItemsState.value

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(horizontal = 16.dp)
    ) {
        item {
            Spacer(modifier = Modifier.height(16.dp))
            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column {
                    Text(
                        text = if (isFakeVault) "Alternative Account" else "Personal Vault",
                        style = MaterialTheme.typography.headlineMedium,
                        fontWeight = FontWeight.ExtraBold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    Text(
                        text = if (isFakeVault) "Decryption key loaded successfully." else "Securely locked and encrypted.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }

                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(CircleShape)
                        .background(if (isFakeVault) MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.3f) else MaterialTheme.colorScheme.primaryContainer.copy(alpha = 0.3f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = Icons.Default.Home,
                        contentDescription = "Shield Indicator",
                        tint = if (isFakeVault) MaterialTheme.colorScheme.error else MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(20.dp)
                    )
                }
            }
            Spacer(modifier = Modifier.height(20.dp))
        }

        item {
            Card(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(bottom = 16.dp),
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically,
                    horizontalArrangement = Arrangement.SpaceBetween
                ) {
                    Column(modifier = Modifier.weight(1.2f)) {
                        Text(
                            text = "Security Score",
                            style = MaterialTheme.typography.titleMedium,
                            fontWeight = FontWeight.Bold,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                        Spacer(modifier = Modifier.height(4.dp))
                        Text(
                            text = if (stats.securityScore >= 90) "Outstanding Protection" else if (stats.securityScore >= 70) "Strong Security" else "Requires Action",
                            style = MaterialTheme.typography.bodySmall,
                            color = if (stats.securityScore >= 70) SuccessGreen else ErrorRed,
                            fontWeight = FontWeight.Bold
                        )
                        Spacer(modifier = Modifier.height(12.dp))
                        Row {
                            Column {
                                Text("${stats.weakPasswordCount}", fontWeight = FontWeight.Bold, color = ErrorRed)
                                Text("Weak", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                            Spacer(modifier = Modifier.width(24.dp))
                            Column {
                                Text("${stats.duplicatePasswordCount}", fontWeight = FontWeight.Bold, color = WarningYellow)
                                Text("Reused", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                            }
                        }
                    }

                    Box(
                        modifier = Modifier
                            .weight(0.8f)
                            .size(100.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        val scoreFloat = stats.securityScore.toFloat() / 100f
                        val animatedScore by animateFloatAsState(targetValue = scoreFloat, animationSpec = tween(1000))
                        val scoreColor = if (stats.securityScore >= 80) SuccessGreen else if (stats.securityScore >= 50) WarningYellow else ErrorRed

                        Canvas(modifier = Modifier.size(80.dp)) {
                            drawArc(
                                color = Color.LightGray.copy(alpha = 0.3f),
                                startAngle = 0f,
                                sweepAngle = 360f,
                                useCenter = false,
                                style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                            )
                            drawArc(
                                color = scoreColor,
                                startAngle = -90f,
                                sweepAngle = animatedScore * 360f,
                                useCenter = false,
                                style = Stroke(width = 8.dp.toPx(), cap = StrokeCap.Round)
                            )
                        }
                        Column(horizontalAlignment = Alignment.CenterHorizontally) {
                            Text(
                                text = "${stats.securityScore}",
                                style = MaterialTheme.typography.titleLarge,
                                fontWeight = FontWeight.ExtraBold,
                                color = MaterialTheme.colorScheme.onBackground
                            )
                            Text(
                                text = "of 100",
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.onSurfaceVariant
                            )
                        }
                    }
                }
            }
        }

        item {
            Text(
                text = "Vault Categories",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }

        item {
            val categories = listOf(
                CategoryGridData("password", "Passwords", Icons.Default.Lock, Color(0xFF3B82F6), stats.totalPasswords),
                CategoryGridData("note", "Secure Notes", Icons.Default.List, Color(0xFFF59E0B), stats.totalNotes),
                CategoryGridData("card", "Credit Cards", Icons.Default.AccountCircle, Color(0xFFEC4899), stats.totalCards),
                CategoryGridData("document", "Documents", Icons.Default.Build, Color(0xFF10B981), stats.totalDocuments),
                CategoryGridData("identity", "Identity", Icons.Default.Person, Color(0xFF8B5CF6), 0),
                CategoryGridData("bank_account", "Banks", Icons.Default.Home, Color(0xFF06B6D4), 0),
                CategoryGridData("crypto", "Crypto Wallets", Icons.Default.Star, Color(0xFFEF4444), 0),
                CategoryGridData("license", "Licenses", Icons.Default.Check, Color(0xFF10B981), 0),
                CategoryGridData("wifi", "WiFi Networks", Icons.Default.Refresh, Color(0xFF3B82F6), 0),
                CategoryGridData("api", "API Tokens", Icons.Default.Warning, Color(0xFFF59E0B), 0)
            )

            LazyVerticalGrid(
                columns = GridCells.Fixed(2),
                modifier = Modifier
                    .height(440.dp)
                    .padding(bottom = 16.dp),
                horizontalArrangement = Arrangement.spacedBy(12.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp),
                userScrollEnabled = false
            ) {
                items(categories) { cat ->
                    Card(
                        onClick = { onNavigate(Screen.AddEdit(category = cat.id)) },
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        shape = RoundedCornerShape(12.dp),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline),
                        modifier = Modifier.testTag("cat_grid_${cat.id}")
                    ) {
                        Row(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(16.dp),
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Box(
                                modifier = Modifier
                                    .size(40.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(cat.color.copy(alpha = 0.15f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Icon(
                                    imageVector = cat.icon,
                                    contentDescription = cat.title,
                                    tint = cat.color,
                                    modifier = Modifier.size(20.dp)
                                )
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                            Column {
                                Text(
                                    text = cat.title,
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground,
                                    maxLines = 1,
                                    overflow = TextOverflow.Ellipsis
                                )
                                Text(
                                    text = "Add Item",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }
                        }
                    }
                }
            }
        }

        if (favorites.isNotEmpty()) {
            item {
                Text(
                    text = "Pinned Favorites",
                    style = MaterialTheme.typography.titleMedium,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground,
                    modifier = Modifier.padding(vertical = 12.dp)
                )
            }
            items(favorites) { decItem ->
                SecretItemRow(decItem, onClick = { onNavigate(Screen.Detail(decItem.item.id)) })
            }
            item { Spacer(modifier = Modifier.height(12.dp)) }
        }

        item {
            Text(
                text = "Recently Modified",
                style = MaterialTheme.typography.titleMedium,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onBackground,
                modifier = Modifier.padding(vertical = 12.dp)
            )
        }

        if (recentItems.isEmpty()) {
            item {
                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(bottom = 32.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface.copy(alpha = 0.5f)),
                    shape = RoundedCornerShape(12.dp),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Box(
                        modifier = Modifier.padding(24.dp),
                        contentAlignment = Alignment.Center
                    ) {
                        Text(
                            text = "No records added to your secure vault yet.",
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            textAlign = TextAlign.Center
                        )
                    }
                }
            }
        } else {
            items(recentItems) { decItem ->
                SecretItemRow(decItem, onClick = { onNavigate(Screen.Detail(decItem.item.id)) })
            }
            item { Spacer(modifier = Modifier.height(40.dp)) }
        }
    }
}

@Composable
fun SecretItemRow(decItem: DecryptedVaultItem, onClick: () -> Unit) {
    val categoryColor = when (decItem.item.category) {
        "password" -> Color(0xFF3B82F6)
        "note" -> Color(0xFFF59E0B)
        "card" -> Color(0xFFEC4899)
        "document" -> Color(0xFF10B981)
        "identity" -> Color(0xFF8B5CF6)
        "wifi" -> Color(0xFF06B6D4)
        else -> Color(0xFF6B7280)
    }

    val icon = when (decItem.item.category) {
        "password" -> Icons.Default.Lock
        "note" -> Icons.Default.List
        "card" -> Icons.Default.AccountCircle
        "document" -> Icons.Default.Build
        "identity" -> Icons.Default.Person
        "wifi" -> Icons.Default.Refresh
        else -> Icons.Default.Info
    }

    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 6.dp)
            .clickable { onClick() },
        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
        shape = RoundedCornerShape(12.dp),
        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Row(verticalAlignment = Alignment.CenterVertically) {
                Box(
                    modifier = Modifier
                        .size(40.dp)
                        .clip(RoundedCornerShape(8.dp))
                        .background(categoryColor.copy(alpha = 0.15f)),
                    contentAlignment = Alignment.Center
                ) {
                    Icon(
                        imageVector = icon,
                        contentDescription = null,
                        tint = categoryColor,
                        modifier = Modifier.size(20.dp)
                    )
                }
                Spacer(modifier = Modifier.width(16.dp))
                Column {
                    Text(
                        text = decItem.item.title,
                        style = MaterialTheme.typography.bodyMedium,
                        fontWeight = FontWeight.Bold,
                        color = MaterialTheme.colorScheme.onBackground
                    )
                    if (decItem.item.subtitle.isNotEmpty()) {
                        Text(
                            text = decItem.item.subtitle,
                            style = MaterialTheme.typography.bodySmall,
                            color = MaterialTheme.colorScheme.onSurfaceVariant,
                            maxLines = 1,
                            overflow = TextOverflow.Ellipsis
                        )
                    }
                }
            }

            Row(verticalAlignment = Alignment.CenterVertically) {
                if (decItem.item.isFavorite) {
                    Icon(
                        imageVector = Icons.Default.Favorite,
                        contentDescription = "Pinned",
                        tint = ErrorRed,
                        modifier = Modifier.size(18.dp)
                    )
                    Spacer(modifier = Modifier.width(12.dp))
                }
                Icon(
                    imageVector = Icons.Default.Star,
                    contentDescription = null,
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(16.dp)
                )
            }
        }
    }
}

@Composable
fun VaultScreen(viewModel: VaultViewModel, onNavigate: (Screen) -> Unit) {
    val items by viewModel.decryptedItems.collectAsState()
    var selectedCategory by remember { mutableStateOf("All") }

    val categories = listOf("All", "Passwords", "Notes", "Cards", "Documents")

    val filteredItems = remember(items, selectedCategory) {
        if (selectedCategory == "All") items else {
            val targetCat = when (selectedCategory) {
                "Passwords" -> "password"
                "Notes" -> "note"
                "Cards" -> "card"
                "Documents" -> "document"
                else -> ""
            }
            items.filter { it.item.category == targetCat }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        Text(
            text = "Your Decrypted Vault",
            style = MaterialTheme.typography.headlineMedium,
            fontWeight = FontWeight.ExtraBold,
            color = MaterialTheme.colorScheme.onBackground
        )

        Spacer(modifier = Modifier.height(16.dp))

        Row(
            modifier = Modifier.fillMaxWidth().height(48.dp),
            horizontalArrangement = Arrangement.spacedBy(8.dp),
            verticalAlignment = Alignment.CenterVertically
        ) {
            categories.forEach { cat ->
                val active = selectedCategory == cat
                val containerColor = if (active) MaterialTheme.colorScheme.primary else MaterialTheme.colorScheme.surface
                val contentColor = if (active) MaterialTheme.colorScheme.background else MaterialTheme.colorScheme.onSurfaceVariant
                val border = if (active) null else BorderStroke(1.dp, MaterialTheme.colorScheme.outline)

                Box(
                    modifier = Modifier
                        .clip(RoundedCornerShape(20.dp))
                        .background(containerColor)
                        .then(if (border != null) Modifier.border(border, RoundedCornerShape(20.dp)) else Modifier)
                        .clickable { selectedCategory = cat }
                        .padding(horizontal = 16.dp, vertical = 8.dp)
                        .testTag("vault_tab_$cat"),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = cat,
                        style = MaterialTheme.typography.bodySmall,
                        fontWeight = FontWeight.Bold,
                        color = contentColor
                    )
                }
            }
        }

        Spacer(modifier = Modifier.height(12.dp))

        if (filteredItems.isEmpty()) {
            Column(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(vertical = 40.dp),
                horizontalAlignment = Alignment.CenterHorizontally,
                verticalArrangement = Arrangement.Center
            ) {
                Icon(
                    imageVector = Icons.Default.Lock,
                    contentDescription = "Empty Logo",
                    tint = MaterialTheme.colorScheme.outline,
                    modifier = Modifier.size(64.dp)
                )
                Spacer(modifier = Modifier.height(12.dp))
                Text(
                    text = "No items found in category '$selectedCategory'",
                    style = MaterialTheme.typography.bodyMedium,
                    color = MaterialTheme.colorScheme.onSurfaceVariant
                )
            }
        } else {
            LazyColumn(
                modifier = Modifier.fillMaxSize()
            ) {
                items(filteredItems) { decItem ->
                    SecretItemRow(decItem, onClick = { onNavigate(Screen.Detail(decItem.item.id)) })
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun SearchScreen(viewModel: VaultViewModel, onNavigate: (Screen) -> Unit) {
    val items by viewModel.decryptedItems.collectAsState()
    val searchQuery by viewModel.searchQuery.collectAsState()
    val recentSearches by viewModel.recentSearches.collectAsState()

    val filteredItems = remember(items, searchQuery) {
        if (searchQuery.trim().isEmpty()) emptyList() else {
            items.filter { decItem ->
                decItem.item.title.contains(searchQuery, ignoreCase = true) ||
                decItem.item.subtitle.contains(searchQuery, ignoreCase = true) ||
                decItem.fields.values.any { it.contains(searchQuery, ignoreCase = true) }
            }
        }
    }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        OutlinedTextField(
            value = searchQuery,
            onValueChange = { viewModel.updateSearchQuery(it) },
            placeholder = { Text("Search logins, notes, licenses, keys...") },
            leadingIcon = { Icon(imageVector = Icons.Default.Search, contentDescription = "Search Icon") },
            trailingIcon = {
                if (searchQuery.isNotEmpty()) {
                    IconButton(onClick = { viewModel.updateSearchQuery("") }) {
                        Icon(imageVector = Icons.Default.Close, contentDescription = "Clear")
                    }
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .testTag("search_field"),
            singleLine = true,
            colors = OutlinedTextFieldDefaults.colors()
        )

        Spacer(modifier = Modifier.height(16.dp))

        if (searchQuery.trim().isEmpty()) {
            if (recentSearches.isNotEmpty()) {
                Text(
                    text = "Recent Searches",
                    style = MaterialTheme.typography.titleSmall,
                    fontWeight = FontWeight.Bold,
                    color = MaterialTheme.colorScheme.onBackground
                )
                Spacer(modifier = Modifier.height(8.dp))
                recentSearches.forEach { search ->
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { viewModel.updateSearchQuery(search) }
                            .padding(vertical = 10.dp),
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Icon(
                            imageVector = Icons.Default.Refresh,
                            contentDescription = "Recent search indicator",
                            tint = MaterialTheme.colorScheme.onSurfaceVariant,
                            modifier = Modifier.size(16.dp)
                        )
                        Spacer(modifier = Modifier.width(12.dp))
                        Text(
                            text = search,
                            style = MaterialTheme.typography.bodyMedium,
                            color = MaterialTheme.colorScheme.onBackground
                        )
                    }
                }
            } else {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "Global real-time search runs completely localized. Your queries never touch the cloud.",
                        style = MaterialTheme.typography.bodySmall,
                        color = MaterialTheme.colorScheme.onSurfaceVariant,
                        textAlign = TextAlign.Center,
                        modifier = Modifier.padding(horizontal = 40.dp)
                    )
                }
            }
        } else {
            if (filteredItems.isEmpty()) {
                Box(
                    modifier = Modifier.fillMaxSize(),
                    contentAlignment = Alignment.Center
                ) {
                    Text(
                        text = "No matching secrets found.",
                        style = MaterialTheme.typography.bodyMedium,
                        color = MaterialTheme.colorScheme.onSurfaceVariant
                    )
                }
            } else {
                LaunchedEffect(searchQuery) {
                    delay(1500)
                    viewModel.addRecentSearch(searchQuery)
                }

                LazyColumn(modifier = Modifier.fillMaxSize()) {
                    items(filteredItems) { decItem ->
                        SecretItemRow(decItem, onClick = { onNavigate(Screen.Detail(decItem.item.id)) })
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsScreen(viewModel: VaultViewModel, onNavigate: (Screen) -> Unit) {
    val context = LocalContext.current
    val clipboardTimeout by viewModel.clipboardTimeout.collectAsState()
    val autoLockDelay by viewModel.autoLockDelay.collectAsState()
    val isBiometricEnabled = viewModel.isBiometricEnabled()
    val hasFakePin = viewModel.hasFakePin()
    val intruderLogs by viewModel.intruderLogs.collectAsState()

    var showClipboardDialog by remember { mutableStateOf(false) }
    var showAutoLockDialog by remember { mutableStateOf(false) }
    var showFakePinDialog by remember { mutableStateOf(false) }

    LazyColumn(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.background)
            .padding(16.dp)
    ) {
        item {
            Text(
                text = "System Settings",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.ExtraBold,
                color = MaterialTheme.colorScheme.onBackground
            )
            Spacer(modifier = Modifier.height(24.dp))
        }

        item {
            Text(
                text = "SECURITY CONTROLS",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            SettingsItemRow(
                title = "Clipboard Auto Clear",
                subtitle = "Erase copied secrets after $clipboardTimeout seconds.",
                onClick = { showClipboardDialog = true }
            )
        }

        item {
            SettingsItemRow(
                title = "Auto Vault Lock",
                subtitle = if (autoLockDelay > 0) "Lock vault after $autoLockDelay minutes of inactivity." else "Vault immediately locks.",
                onClick = { showAutoLockDialog = true }
            )
        }

        item {
            var bioState by remember { mutableStateOf(isBiometricEnabled) }
            Row(
                modifier = Modifier
                    .fillMaxWidth()
                    .padding(vertical = 12.dp),
                horizontalArrangement = Arrangement.SpaceBetween,
                verticalAlignment = Alignment.CenterVertically
            ) {
                Column(modifier = Modifier.weight(1.5f)) {
                    Text("Biometric Authentication", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Text("Use fingerprint or face recognition context to bypass keyboard PIN typing.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                }
                Switch(
                    checked = bioState,
                    onCheckedChange = { checked ->
                        if (checked) {
                            val success = viewModel.enableBiometric("1234")
                            if (success) {
                                bioState = true
                                Toast.makeText(context, "Biometrics Linked", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "Setup master PIN backup first", Toast.LENGTH_SHORT).show()
                            }
                        } else {
                            viewModel.disableBiometric()
                            bioState = false
                            Toast.makeText(context, "Biometrics Disabled", Toast.LENGTH_SHORT).show()
                        }
                    },
                    colors = SwitchDefaults.colors(checkedThumbColor = MaterialTheme.colorScheme.primary)
                )
            }
            Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 0.8.dp)
        }

        item {
            SettingsItemRow(
                title = "Alternative Account PIN",
                subtitle = if (hasFakePin) "Configured (Plausible Deniability Ready)" else "Set up secondary fake PIN for fake datasets.",
                onClick = { showFakePinDialog = true }
            )
        }

        item {
            SettingsItemRow(
                title = "Intruder Alert Log",
                subtitle = if (intruderLogs.isNotEmpty()) "Alert: ${intruderLogs.size} failed unlock logs recorded." else "No failed attempts detected.",
                onClick = { onNavigate(Screen.IntruderLogs) }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "DATABASE BACKUP",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            SettingsItemRow(
                title = "Export Encrypted Backup (JSON)",
                subtitle = "Generate an offline, military-grade GCM-encrypted database file.",
                onClick = {
                    val file = viewModel.exportBackupEncrypted(context)
                    if (file != null) {
                        Toast.makeText(context, "Backup written to cache: ${file.name}", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Failed generating backup payload.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        item {
            SettingsItemRow(
                title = "Export Unencrypted CSV",
                subtitle = "Generates plain-text CSV schema file (Not Secure!). For local audits.",
                onClick = {
                    val file = viewModel.exportToCSV(context)
                    if (file != null) {
                        Toast.makeText(context, "Audit sheet exported successfully: ${file.name}", Toast.LENGTH_LONG).show()
                    } else {
                        Toast.makeText(context, "Failed exporting CSV records.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        item {
            SettingsItemRow(
                title = "Import Database JSON",
                subtitle = "Restore passwords and cards from a valid backup file.",
                onClick = {
                    val mockBackup = "{\"vault9_encrypted_backup\":true,\"payload\":\"MOCK_DUMMY_PAYLOAD\",\"iv\":\"MOCK_IV\"}"
                    val ok = viewModel.importBackupEncrypted(mockBackup)
                    if (ok) {
                        Toast.makeText(context, "Database records restored.", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(context, "Invalid backup signature verified.", Toast.LENGTH_SHORT).show()
                    }
                }
            )
        }

        item {
            Spacer(modifier = Modifier.height(24.dp))
            Text(
                text = "ABOUT & PRIVACY",
                style = MaterialTheme.typography.titleSmall,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(8.dp))
        }

        item {
            Column(modifier = Modifier.padding(vertical = 12.dp)) {
                Text("Vault9 Locker", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Text("Version 1.0.0 (Military-Grade Cryptography GCM-AES256). All databases and secrets remain strictly offline on your hardware context.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
            }
        }
    }

    if (showClipboardDialog) {
        SimpleOptionSelectorDialog(
            title = "Clipboard Timeout",
            options = listOf(15, 30, 60),
            onSelect = {
                viewModel.updateClipboardTimeout(it)
                showClipboardDialog = false
            },
            onDismiss = { showClipboardDialog = false }
        )
    }

    if (showAutoLockDialog) {
        SimpleOptionSelectorDialog(
            title = "Auto Vault Lock",
            options = listOf(0, 1, 5, 10, 30),
            onSelect = {
                viewModel.updateAutoLockDelay(it)
                showAutoLockDialog = false
            },
            onDismiss = { showAutoLockDialog = false }
        )
    }

    if (showFakePinDialog) {
        var fakePinText by remember { mutableStateOf("") }
        Dialog(onDismissRequest = { showFakePinDialog = false }) {
            Card(
                shape = RoundedCornerShape(16.dp),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
                modifier = Modifier.padding(16.dp),
                border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
            ) {
                Column(modifier = Modifier.padding(20.dp)) {
                    Text("Plausible Deniability Setup", style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                    Spacer(modifier = Modifier.height(8.dp))
                    Text("Configure a secondary fake PIN. Logging in with this PIN will load a fake safe space.", style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
                    Spacer(modifier = Modifier.height(16.dp))
                    OutlinedTextField(
                        value = fakePinText,
                        onValueChange = { if (it.all { c -> c.isDigit() } && it.length <= 6) fakePinText = it },
                        label = { Text("Secondary PIN (4-6 digits)") },
                        visualTransformation = PasswordVisualTransformation(),
                        modifier = Modifier.fillMaxWidth().testTag("fake_pin_setup_input")
                    )
                    Spacer(modifier = Modifier.height(16.dp))
                    Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.End) {
                        if (hasFakePin) {
                            OutlinedButton(onClick = {
                                viewModel.removeFakePin()
                                showFakePinDialog = false
                                Toast.makeText(context, "Dual PIN Removed", Toast.LENGTH_SHORT).show()
                            }) {
                                Text("Disable Dual PIN")
                            }
                            Spacer(modifier = Modifier.width(12.dp))
                        }
                        Button(onClick = {
                            if (fakePinText.length >= 4) {
                                viewModel.setupFakePin(fakePinText)
                                showFakePinDialog = false
                                Toast.makeText(context, "Alternative PIN Set", Toast.LENGTH_SHORT).show()
                            } else {
                                Toast.makeText(context, "PIN must be 4-6 digits", Toast.LENGTH_SHORT).show()
                            }
                        }) {
                            Text("Save PIN")
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun SettingsItemRow(title: String, subtitle: String, onClick: () -> Unit) {
    Column(
        modifier = Modifier
            .fillMaxWidth()
            .clickable { onClick() }
            .padding(vertical = 12.dp)
    ) {
        Text(title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
        Text(subtitle, style = MaterialTheme.typography.bodySmall, color = MaterialTheme.colorScheme.onSurfaceVariant)
        Spacer(modifier = Modifier.height(12.dp))
        Divider(color = MaterialTheme.colorScheme.outline.copy(alpha = 0.5f), thickness = 0.8.dp)
    }
}

@Composable
fun SimpleOptionSelectorDialog(title: String, options: List<Int>, onSelect: (Int) -> Unit, onDismiss: () -> Unit) {
    Dialog(onDismissRequest = onDismiss) {
        Card(
            shape = RoundedCornerShape(16.dp),
            colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.background),
            modifier = Modifier.padding(16.dp),
            border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
        ) {
            Column(modifier = Modifier.padding(20.dp)) {
                Text(title, style = MaterialTheme.typography.titleMedium, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                Spacer(modifier = Modifier.height(12.dp))
                options.forEach { opt ->
                    val label = when (opt) {
                        0 -> "Immediately"
                        else -> "$opt Seconds/Minutes"
                    }
                    Row(
                        modifier = Modifier
                            .fillMaxWidth()
                            .clickable { onSelect(opt) }
                            .padding(vertical = 12.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Text(label, style = MaterialTheme.typography.bodyMedium, color = MaterialTheme.colorScheme.onBackground)
                    }
                }
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun DetailScreen(viewModel: VaultViewModel, itemId: Int, onNavigateBack: () -> Unit, onEditClick: (Int, String) -> Unit) {
    val items by viewModel.decryptedItems.collectAsState()
    val decrypted = items.find { it.item.id == itemId }
    val context = LocalContext.current

    if (decrypted == null) {
        Box(modifier = Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
            Text("Decrypting secret data payload...")
        }
        return
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(decrypted.item.title, fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = { viewModel.toggleFavorite(decrypted.item) }) {
                        Icon(
                            imageVector = if (decrypted.item.isFavorite) Icons.Default.Favorite else Icons.Default.FavoriteBorder,
                            contentDescription = "Pin Favorite",
                            tint = if (decrypted.item.isFavorite) ErrorRed else MaterialTheme.colorScheme.onBackground
                        )
                    }
                    IconButton(onClick = {
                        viewModel.trashItem(decrypted.item)
                        onNavigateBack()
                        Toast.makeText(context, "Item moved to secure trash bin.", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Trash")
                    }
                },
                colors = TopAppBarDefaults.topAppBarColors(containerColor = MaterialTheme.colorScheme.background)
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            item {
                if (decrypted.item.category == "card") {
                    val cardNum = decrypted.fields["card_number"] ?: "•••• •••• •••• ••••"
                    var revealCardNum by remember { mutableStateOf(false) }
                    val displayCardNum = if (revealCardNum) cardNum else "•••• •••• •••• " + cardNum.takeLast(4)

                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .height(200.dp)
                            .padding(bottom = 24.dp)
                            .clickable { revealCardNum = !revealCardNum },
                        shape = RoundedCornerShape(16.dp),
                        colors = CardDefaults.cardColors(containerColor = Color(0xFF1E293B))
                    ) {
                        Column(
                            modifier = Modifier
                                .fillMaxSize()
                                .padding(24.dp),
                            verticalArrangement = Arrangement.SpaceBetween
                        ) {
                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Text("Vault9 SECURE", color = Color.White.copy(alpha = 0.8f), fontWeight = FontWeight.ExtraBold)
                                Icon(imageVector = Icons.Default.Star, contentDescription = "Chip", tint = Color(0xFFF59E0B), modifier = Modifier.size(24.dp))
                            }

                            Text(
                                text = displayCardNum,
                                style = MaterialTheme.typography.headlineMedium,
                                color = Color.White,
                                letterSpacing = 2.sp,
                                fontWeight = FontWeight.Bold
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Column {
                                    Text("CARD HOLDER", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
                                    Text(decrypted.fields["holder_name"] ?: "SECURE HOLDER", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                                Column {
                                    Text("EXPIRES", style = MaterialTheme.typography.labelSmall, color = Color.White.copy(alpha = 0.5f))
                                    Text(decrypted.fields["expiry_date"] ?: "MM/YY", color = Color.White, fontWeight = FontWeight.Bold)
                                }
                            }
                        }
                    }
                }
            }

            items(decrypted.fields.toList()) { pair ->
                val key = pair.first
                val value = pair.second
                var hideField by remember { mutableStateOf(key == "password" || key == "cvv" || key == "atm_pin" || key == "seed_phrase" || key == "private_key" || key == "api_key") }
                val labelText = key.replace("_", " ").uppercase()

                Card(
                    modifier = Modifier
                        .fillMaxWidth()
                        .padding(vertical = 6.dp),
                    shape = RoundedCornerShape(12.dp),
                    colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                    border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                ) {
                    Row(
                        modifier = Modifier.padding(16.dp),
                        horizontalArrangement = Arrangement.SpaceBetween,
                        verticalAlignment = Alignment.CenterVertically
                    ) {
                        Column(modifier = Modifier.weight(1.5f)) {
                            Text(
                                text = labelText,
                                style = MaterialTheme.typography.labelSmall,
                                color = MaterialTheme.colorScheme.primary,
                                fontWeight = FontWeight.Bold
                            )
                            Spacer(modifier = Modifier.height(4.dp))
                            Text(
                                text = if (hideField) "••••••••••••" else value,
                                style = MaterialTheme.typography.bodyMedium,
                                color = MaterialTheme.colorScheme.onBackground,
                                fontWeight = FontWeight.SemiBold
                            )
                        }

                        Row(modifier = Modifier.weight(0.5f), horizontalArrangement = Arrangement.End) {
                            if (key == "password" || key == "cvv" || key == "atm_pin" || key == "seed_phrase" || key == "private_key") {
                                IconButton(onClick = { hideField = !hideField }) {
                                    Icon(
                                        imageVector = if (hideField) Icons.Default.Close else Icons.Default.Check,
                                        contentDescription = "Toggle Visibility"
                                    )
                                }
                            }
                            IconButton(onClick = {
                                viewModel.copyToClipboard(labelText, value)
                                Toast.makeText(context, "$labelText copied to secure clipboard.", Toast.LENGTH_SHORT).show()
                            }) {
                                Icon(imageVector = Icons.Default.Add, contentDescription = "Copy")
                            }
                        }
                    }
                }
            }

            if (decrypted.item.category == "password") {
                val password = decrypted.fields["password"] ?: ""
                val strength = viewModel.calculatePasswordStrength(password)
                val (strengthText, color) = when (strength) {
                    0 -> "Extremely Vulnerable" to ErrorRed
                    1 -> "Weak Password" to ErrorRed
                    2 -> "Fair Protection" to WarningYellow
                    3 -> "Strong Encryption" to SuccessGreen
                    else -> "Military-grade GCM Resistant" to SuccessGreen
                }

                item {
                    Spacer(modifier = Modifier.height(16.dp))
                    Card(
                        modifier = Modifier.fillMaxWidth(),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = color.copy(alpha = 0.1f)),
                        border = BorderStroke(1.dp, color.copy(alpha = 0.3f))
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Password Security Strength", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.height(8.dp))
                            Row(modifier = Modifier.fillMaxWidth()) {
                                for (i in 0..4) {
                                    val active = i <= strength
                                    Box(
                                        modifier = Modifier
                                            .weight(1f)
                                            .padding(horizontal = 2.dp)
                                            .height(6.dp)
                                            .clip(RoundedCornerShape(3.dp))
                                            .background(if (active) color else Color.LightGray.copy(alpha = 0.3f))
                                    )
                                }
                            }
                            Spacer(modifier = Modifier.height(8.dp))
                            Text(strengthText, color = color, style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = { onEditClick(decrypted.item.id, decrypted.item.category) },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Modify Secret Record", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddEditScreen(viewModel: VaultViewModel, category: String, itemId: Int? = null, onNavigateBack: () -> Unit) {
    val context = LocalContext.current
    val items by viewModel.decryptedItems.collectAsState()
    val isEdit = itemId != null
    val targetItem = if (isEdit) items.find { it.item.id == itemId } else null

    var title by remember { mutableStateOf(targetItem?.item?.title ?: "") }

    val fields = remember { mutableStateMapOf<String, String>() }

    LaunchedEffect(targetItem) {
        if (targetItem != null) {
            targetItem.fields.forEach { (k, v) -> fields[k] = v }
        } else {
            when (category) {
                "password" -> {
                    fields["username"] = ""
                    fields["password"] = ""
                    fields["url"] = ""
                    fields["notes"] = ""
                }
                "note" -> {
                    fields["content"] = ""
                    fields["notes"] = ""
                }
                "card" -> {
                    fields["holder_name"] = ""
                    fields["card_number"] = ""
                    fields["expiry_date"] = ""
                    fields["cvv"] = ""
                    fields["atm_pin"] = ""
                }
                "document" -> {
                    fields["document_id"] = ""
                    fields["notes"] = ""
                }
                "identity" -> {
                    fields["full_name"] = ""
                    fields["address"] = ""
                    fields["phone"] = ""
                    fields["email"] = ""
                }
                "bank_account" -> {
                    fields["bank_name"] = ""
                    fields["account_number"] = ""
                    fields["ifsc"] = ""
                }
                "crypto" -> {
                    fields["wallet_name"] = ""
                    fields["address"] = ""
                    fields["seed_phrase"] = ""
                }
                "license" -> {
                    fields["product_name"] = ""
                    fields["license_key"] = ""
                }
                "wifi" -> {
                    fields["network_ssid"] = ""
                    fields["password"] = ""
                }
                "api" -> {
                    fields["api_name"] = ""
                    fields["api_key"] = ""
                }
            }
        }
    }

    var showPwGenerator by remember { mutableStateOf(false) }
    var pwLength by remember { mutableStateOf(16f) }
    var pwUpper by remember { mutableStateOf(true) }
    var pwLower by remember { mutableStateOf(true) }
    var pwNum by remember { mutableStateOf(true) }
    var pwSym by remember { mutableStateOf(true) }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text(if (isEdit) "Modify Secret" else "New $category", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                }
            )
        }
    ) { innerPadding ->
        LazyColumn(
            modifier = Modifier
                .fillMaxSize()
                .background(MaterialTheme.colorScheme.background)
                .padding(innerPadding)
                .padding(16.dp)
        ) {
            item {
                OutlinedTextField(
                    value = title,
                    onValueChange = { title = it },
                    label = { Text("Title / Name") },
                    modifier = Modifier.fillMaxWidth().testTag("title_field"),
                    colors = OutlinedTextFieldDefaults.colors()
                )
                Spacer(modifier = Modifier.height(12.dp))
            }

            items(fields.keys.toList()) { key ->
                val displayLabel = key.replace("_", " ").uppercase()
                val value = fields[key] ?: ""

                Column(modifier = Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    OutlinedTextField(
                        value = value,
                        onValueChange = { fields[key] = it },
                        label = { Text(displayLabel) },
                        modifier = Modifier.fillMaxWidth().testTag("field_$key"),
                        colors = OutlinedTextFieldDefaults.colors()
                    )

                    if (key == "password") {
                        Spacer(modifier = Modifier.height(4.dp))
                        OutlinedButton(
                            onClick = { showPwGenerator = !showPwGenerator },
                            modifier = Modifier.align(Alignment.End)
                        ) {
                            Text(if (showPwGenerator) "Hide Generator" else "Secure Generator Key")
                        }
                    }
                }
            }

            if (showPwGenerator) {
                item {
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.outline)
                    ) {
                        Column(modifier = Modifier.padding(16.dp)) {
                            Text("Secure Password Generator", fontWeight = FontWeight.Bold, color = MaterialTheme.colorScheme.onBackground)
                            Spacer(modifier = Modifier.height(8.dp))
                            
                            Text("Length: ${pwLength.toInt()}", style = MaterialTheme.typography.bodySmall, fontWeight = FontWeight.Bold)
                            Slider(
                                value = pwLength,
                                onValueChange = { pwLength = it },
                                valueRange = 8f..64f,
                                colors = SliderDefaults.colors(thumbColor = MaterialTheme.colorScheme.primary)
                            )

                            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = pwUpper, onCheckedChange = { pwUpper = it })
                                    Text("A-Z", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = pwLower, onCheckedChange = { pwLower = it })
                                    Text("a-z", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = pwNum, onCheckedChange = { pwNum = it })
                                    Text("0-9", style = MaterialTheme.typography.bodySmall)
                                }
                                Row(verticalAlignment = Alignment.CenterVertically) {
                                    Checkbox(checked = pwSym, onCheckedChange = { pwSym = it })
                                    Text("@#$", style = MaterialTheme.typography.bodySmall)
                                }
                            }

                            Spacer(modifier = Modifier.height(12.dp))

                            Button(
                                onClick = {
                                    val generated = viewModel.generatePassword(
                                        length = pwLength.toInt(),
                                        useUpper = pwUpper,
                                        useLower = pwLower,
                                        useNumbers = pwNum,
                                        useSymbols = pwSym,
                                        excludeSimilar = true,
                                        excludeAmbiguous = false
                                    )
                                    fields["password"] = generated
                                },
                                modifier = Modifier.fillMaxWidth()
                            ) {
                                Text("Generate Password")
                            }
                        }
                    }
                }
            }

            item {
                Spacer(modifier = Modifier.height(32.dp))
                Button(
                    onClick = {
                        if (title.trim().isEmpty()) {
                            Toast.makeText(context, "Title cannot be left empty.", Toast.LENGTH_SHORT).show()
                            return@Button
                        }
                        
                        val computedSubtitle = when (category) {
                            "password" -> fields["username"] ?: ""
                            "card" -> "Expires " + (fields["expiry_date"] ?: "MM/YY")
                            "wifi" -> fields["network_ssid"] ?: ""
                            else -> ""
                        }

                        viewModel.saveItem(
                            id = itemId ?: 0,
                            category = category,
                            title = title,
                            subtitle = computedSubtitle,
                            fields = fields.toMap()
                        )

                        onNavigateBack()
                        Toast.makeText(context, "Encrypted vault record saved.", Toast.LENGTH_SHORT).show()
                    },
                    modifier = Modifier
                        .fillMaxWidth()
                        .height(52.dp)
                        .testTag("save_button"),
                    shape = RoundedCornerShape(12.dp)
                ) {
                    Text("Encrypt and Save Secret", fontWeight = FontWeight.Bold)
                }
                Spacer(modifier = Modifier.height(40.dp))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun IntruderLogsScreen(viewModel: VaultViewModel, onNavigateBack: () -> Unit) {
    val intruderLogs by viewModel.intruderLogs.collectAsState()
    val context = LocalContext.current

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("Failed Logins Alert", fontWeight = FontWeight.Bold) },
                navigationIcon = {
                    IconButton(onClick = onNavigateBack) {
                        Icon(imageVector = Icons.Default.ArrowBack, contentDescription = "Back")
                    }
                },
                actions = {
                    IconButton(onClick = {
                        viewModel.clearIntruderLogs()
                        Toast.makeText(context, "Intruder security logs cleared", Toast.LENGTH_SHORT).show()
                    }) {
                        Icon(imageVector = Icons.Default.Delete, contentDescription = "Clear Logs")
                    }
                }
            )
        }
    ) { innerPadding ->
        if (intruderLogs.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("No failed attempts. Your vault remains fully secured.")
            }
        } else {
            LazyColumn(
                modifier = Modifier
                    .fillMaxSize()
                    .background(MaterialTheme.colorScheme.background)
                    .padding(innerPadding)
                    .padding(16.dp)
            ) {
                items(intruderLogs) { log ->
                    Card(
                        modifier = Modifier
                            .fillMaxWidth()
                            .padding(vertical = 6.dp),
                        shape = RoundedCornerShape(12.dp),
                        colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.errorContainer.copy(alpha = 0.15f)),
                        border = BorderStroke(1.dp, MaterialTheme.colorScheme.error.copy(alpha = 0.3f))
                    ) {
                        Row(
                            modifier = Modifier.padding(16.dp),
                            horizontalArrangement = Arrangement.SpaceBetween,
                            verticalAlignment = Alignment.CenterVertically
                        ) {
                            Column {
                                val df = SimpleDateFormat("yyyy-MM-dd HH:mm:ss", Locale.getDefault())
                                Text(
                                    text = "ALERT: FAILED UNLOCK ATTEMPT",
                                    style = MaterialTheme.typography.labelSmall,
                                    color = MaterialTheme.colorScheme.error,
                                    fontWeight = FontWeight.Bold
                                )
                                Spacer(modifier = Modifier.height(4.dp))
                                Text(
                                    text = df.format(Date(log.timestamp)),
                                    style = MaterialTheme.typography.bodyMedium,
                                    fontWeight = FontWeight.Bold,
                                    color = MaterialTheme.colorScheme.onBackground
                                )
                                Text(
                                    text = "Consecutive attempt #${log.attemptCount}",
                                    style = MaterialTheme.typography.bodySmall,
                                    color = MaterialTheme.colorScheme.onSurfaceVariant
                                )
                            }

                            Box(
                                modifier = Modifier
                                    .size(56.dp)
                                    .clip(RoundedCornerShape(8.dp))
                                    .background(Color.Gray.copy(alpha = 0.2f)),
                                contentAlignment = Alignment.Center
                            ) {
                                Column(horizontalAlignment = Alignment.CenterHorizontally) {
                                    Icon(imageVector = Icons.Default.Person, contentDescription = "Selfie", tint = MaterialTheme.colorScheme.error, modifier = Modifier.size(24.dp))
                                    Text("Selfie", style = MaterialTheme.typography.labelSmall, color = MaterialTheme.colorScheme.error)
                                }
                            }
                        }
                    }
                }
            }
        }
    }
}

@Composable
fun Dialog(onDismissRequest: () -> Unit, content: @Composable () -> Unit) {
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color.Black.copy(alpha = 0.5f))
            .clickable(onClick = onDismissRequest),
        contentAlignment = Alignment.Center
    ) {
        Box(
            modifier = Modifier.clickable(
                onClick = {},
                interactionSource = remember { MutableInteractionSource() },
                indication = null
            )
        ) {
            content()
        }
    }
}

@Composable
fun BorderStroke(width: androidx.compose.ui.unit.Dp, color: Color) = androidx.compose.foundation.BorderStroke(width, color)

data class CategoryGridData(
    val id: String,
    val title: String,
    val icon: androidx.compose.ui.graphics.vector.ImageVector,
    val color: Color,
    val count: Int
)
