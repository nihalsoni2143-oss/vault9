package com.example.ui

import android.app.Application
import android.content.Context
import android.util.Base64
import android.util.Log
import androidx.lifecycle.AndroidViewModel
import androidx.lifecycle.viewModelScope
import com.example.data.AppDatabase
import com.example.data.VaultItem
import com.example.data.VaultItemRepository
import com.example.security.SecurityManager
import com.example.security.UnlockResult
import kotlinx.coroutines.Job
import kotlinx.coroutines.delay
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.SharingStarted
import kotlinx.coroutines.flow.StateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.combine
import kotlinx.coroutines.flow.map
import kotlinx.coroutines.flow.stateIn
import kotlinx.coroutines.launch
import org.json.JSONArray
import org.json.JSONObject
import java.io.File
import java.security.SecureRandom

class VaultViewModel(application: Application) : AndroidViewModel(application) {
    private val repository: VaultItemRepository
    
    // UI states
    private val _isUnlocked = MutableStateFlow(false)
    val isUnlocked: StateFlow<Boolean> = _isUnlocked.asStateFlow()

    private val _isFakeVault = MutableStateFlow(false)
    val isFakeVault: StateFlow<Boolean> = _isFakeVault.asStateFlow()

    private val _hasPin = MutableStateFlow(false)
    val hasPin: StateFlow<Boolean> = _hasPin.asStateFlow()

    private val _securityWarning = MutableStateFlow<String?>(null)
    val securityWarning: StateFlow<String?> = _securityWarning.asStateFlow()

    // Clipboard settings
    private val _clipboardTimeout = MutableStateFlow(30) // seconds
    val clipboardTimeout: StateFlow<Int> = _clipboardTimeout.asStateFlow()

    // Auto-lock settings
    private val _autoLockDelay = MutableStateFlow(1) // in minutes, 0 means Immediately, -1 means Never
    val autoLockDelay: StateFlow<Int> = _autoLockDelay.asStateFlow()

    // Search query
    private val _searchQuery = MutableStateFlow("")
    val searchQuery: StateFlow<String> = _searchQuery.asStateFlow()

    // Selected folder & tags filtering
    private val _selectedFolder = MutableStateFlow<String?>(null)
    val selectedFolder: StateFlow<String?> = _selectedFolder.asStateFlow()

    private val _selectedTag = MutableStateFlow<String?>(null)
    val selectedTag: StateFlow<String?> = _selectedTag.asStateFlow()

    private val _showArchived = MutableStateFlow(false)
    private val _showDeleted = MutableStateFlow(false)

    // Database Flows
    private val _rawItems = MutableStateFlow<List<VaultItem>>(emptyList())
    
    // Decrypted Items Cache to avoid decrypting on every frame
    private val _decryptedItems = MutableStateFlow<List<DecryptedVaultItem>>(emptyList())
    val decryptedItems: StateFlow<List<DecryptedVaultItem>> = _decryptedItems.asStateFlow()

    // Favorites
    val favoriteItems: StateFlow<List<DecryptedVaultItem>> = _decryptedItems.map { items ->
        items.filter { it.item.isFavorite }
    }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())

    // Recent Items
    fun getRecentItems(limit: Int): StateFlow<List<DecryptedVaultItem>> {
        return _decryptedItems.map { items ->
            items.sortedByDescending { it.item.updatedAt }.take(limit)
        }.stateIn(viewModelScope, SharingStarted.WhileSubscribed(5000), emptyList())
    }

    // Trash Bin
    private val _deletedItemsFlow = MutableStateFlow<List<DecryptedVaultItem>>(emptyList())
    val deletedItems: StateFlow<List<DecryptedVaultItem>> = _deletedItemsFlow.asStateFlow()

    // Archived
    private val _archivedItemsFlow = MutableStateFlow<List<DecryptedVaultItem>>(emptyList())
    val archivedItems: StateFlow<List<DecryptedVaultItem>> = _archivedItemsFlow.asStateFlow()

    // Stats and Dashboard Info
    private val _dashboardStats = MutableStateFlow(DashboardStats())
    val dashboardStats: StateFlow<DashboardStats> = _dashboardStats.asStateFlow()

    // Recent Searches
    private val _recentSearches = MutableStateFlow<List<String>>(emptyList())
    val recentSearches: StateFlow<List<String>> = _recentSearches.asStateFlow()

    // Auto-Lock Background Tracker
    private var lastActiveTime: Long = System.currentTimeMillis()
    private var autoLockJob: Job? = null

    // Intruder Attempts Tracker
    private val _failedUnlockAttempts = MutableStateFlow(0)
    private val _isBruteForceLocked = MutableStateFlow(false)
    val isBruteForceLocked: StateFlow<Boolean> = _isBruteForceLocked.asStateFlow()
    private val _bruteForceCooldown = MutableStateFlow(0) // in seconds
    val bruteForceCooldown: StateFlow<Int> = _bruteForceCooldown.asStateFlow()

    // Intruder Logs
    private val _intruderLogs = MutableStateFlow<List<IntruderLog>>(emptyList())
    val intruderLogs: StateFlow<List<IntruderLog>> = _intruderLogs.asStateFlow()

    init {
        val database = AppDatabase.getDatabase(application)
        repository = VaultItemRepository(database.vaultItemDao())
        
        checkPinSetup()
        checkEnvironmentSecurity()
        startAutoLockMonitor()

        // Load recent searches and settings from SharedPreferences
        loadSettings()

        // Observe database
        viewModelScope.launch {
            repository.allItems.collect { rawList ->
                _rawItems.value = rawList
                decryptAndCacheItems(rawList)
            }
        }

        viewModelScope.launch {
            repository.deletedItems.collect { deletedRaw ->
                decryptDeletedItems(deletedRaw)
            }
        }

        viewModelScope.launch {
            repository.archivedItems.collect { archivedRaw ->
                decryptArchivedItems(archivedRaw)
            }
        }
    }

    private fun checkPinSetup() {
        _hasPin.value = SecurityManager.hasMasterPin(getApplication())
    }

    private fun checkEnvironmentSecurity() {
        val context = getApplication<Application>()
        if (SecurityManager.isDeviceRooted()) {
            _securityWarning.value = "Security Alert: This device appears to be ROOTED. Your digital locker is running in reduced security mode to protect against memory tampering."
        } else if (SecurityManager.isRunningOnEmulator()) {
            _securityWarning.value = "Security Notice: Emulator detected. Screenshots and screen recordings are permitted for testing, but are disabled on physical devices for military-grade protection."
        }
    }

    private fun loadSettings() {
        val prefs = getApplication<Application>().getSharedPreferences("vault9_settings", Context.MODE_PRIVATE)
        _clipboardTimeout.value = prefs.getInt("clipboard_timeout", 30)
        _autoLockDelay.value = prefs.getInt("auto_lock_delay", 1)
        
        // Load recent searches
        val searchesStr = prefs.getString("recent_searches", "") ?: ""
        if (searchesStr.isNotEmpty()) {
            _recentSearches.value = searchesStr.split("|||").filter { it.isNotEmpty() }
        }

        // Load intruder logs
        val logsStr = prefs.getString("intruder_logs", "") ?: ""
        if (logsStr.isNotEmpty()) {
            val logsList = mutableListOf<IntruderLog>()
            try {
                val array = JSONArray(logsStr)
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    logsList.add(IntruderLog(
                        timestamp = obj.getLong("timestamp"),
                        attemptCount = obj.getInt("attemptCount"),
                        photoPath = obj.optString("photoPath", null)
                    ))
                }
            } catch (e: Exception) {
                Log.e("VaultViewModel", "Failed to load intruder logs", e)
            }
            _intruderLogs.value = logsList
        }
    }

    private fun saveSettings() {
        val prefs = getApplication<Application>().getSharedPreferences("vault9_settings", Context.MODE_PRIVATE)
        prefs.edit()
            .putInt("clipboard_timeout", _clipboardTimeout.value)
            .putInt("auto_lock_delay", _autoLockDelay.value)
            .putString("recent_searches", _recentSearches.value.joinToString("|||"))
            .apply()
    }

    private fun saveIntruderLogs() {
        val prefs = getApplication<Application>().getSharedPreferences("vault9_settings", Context.MODE_PRIVATE)
        val array = JSONArray()
        _intruderLogs.value.forEach { log ->
            val obj = JSONObject().apply {
                put("timestamp", log.timestamp)
                put("attemptCount", log.attemptCount)
                put("photoPath", log.photoPath)
            }
            array.put(obj)
        }
        prefs.edit().putString("intruder_logs", array.toString()).apply()
    }

    fun updateClipboardTimeout(seconds: Int) {
        _clipboardTimeout.value = seconds
        saveSettings()
    }

    fun updateAutoLockDelay(minutes: Int) {
        _autoLockDelay.value = minutes
        saveSettings()
    }

    /**
     * Authenticate and unlock
     */
    fun unlockWithPin(pin: String): UnlockResult {
        if (_isBruteForceLocked.value) {
            return UnlockResult.FAILED
        }

        val result = SecurityManager.unlockWithPin(getApplication(), pin)
        if (result == UnlockResult.SUCCESS || result == UnlockResult.SUCCESS_FAKE) {
            _isUnlocked.value = true
            _isFakeVault.value = (result == UnlockResult.SUCCESS_FAKE)
            _failedUnlockAttempts.value = 0
            
            // Reload DB items to trigger decryption with the newly derived key!
            viewModelScope.launch {
                repository.allItems.collect { rawList ->
                    _rawItems.value = rawList
                    decryptAndCacheItems(rawList)
                }
            }
        } else {
            // Unlocked failed
            _failedUnlockAttempts.value += 1
            logFailedAttempt()

            if (_failedUnlockAttempts.value >= 5) {
                triggerBruteForceCooldown()
            }
        }
        return result
    }

    private fun logFailedAttempt() {
        val count = _failedUnlockAttempts.value
        val log = IntruderLog(
            timestamp = System.currentTimeMillis(),
            attemptCount = count,
            photoPath = "selfie_mock_intruder_$count.jpg" // mock front selfie photo name
        )
        val currentLogs = _intruderLogs.value.toMutableList()
        currentLogs.add(0, log)
        _intruderLogs.value = currentLogs
        saveIntruderLogs()
    }

    fun clearIntruderLogs() {
        _intruderLogs.value = emptyList()
        saveIntruderLogs()
    }

    private fun triggerBruteForceCooldown() {
        _isBruteForceLocked.value = true
        _bruteForceCooldown.value = 30 // 30 seconds cooldown
        viewModelScope.launch {
            while (_bruteForceCooldown.value > 0) {
                delay(1000)
                _bruteForceCooldown.value -= 1
            }
            _isBruteForceLocked.value = false
            _failedUnlockAttempts.value = 0
        }
    }

    fun unlockWithBiometrics(): Boolean {
        if (_isBruteForceLocked.value) return false

        val success = SecurityManager.unlockWithBiometrics(getApplication())
        if (success) {
            _isUnlocked.value = true
            _isFakeVault.value = false
            _failedUnlockAttempts.value = 0
            // Reload DB
            viewModelScope.launch {
                repository.allItems.collect { rawList ->
                    _rawItems.value = rawList
                    decryptAndCacheItems(rawList)
                }
            }
        }
        return success
    }

    fun enableBiometric(pin: String): Boolean {
        return SecurityManager.enableBiometricUnlock(getApplication(), pin)
    }

    fun disableBiometric() {
        SecurityManager.disableBiometricUnlock(getApplication())
    }

    fun isBiometricEnabled(): Boolean {
        return SecurityManager.isBiometricEnabled(getApplication())
    }

    fun setupMasterPin(pin: String): Boolean {
        val success = SecurityManager.setupMasterPin(getApplication(), pin)
        if (success) {
            _hasPin.value = true
            _isUnlocked.value = true
        }
        return success
    }

    fun setupFakePin(pin: String) {
        SecurityManager.setupFakePin(getApplication(), pin)
    }

    fun removeFakePin() {
        SecurityManager.removeFakePin(getApplication())
    }

    fun hasFakePin(): Boolean {
        return SecurityManager.hasFakePin(getApplication())
    }

    fun lock() {
        SecurityManager.lock()
        _isUnlocked.value = false
        _isFakeVault.value = false
        _decryptedItems.value = emptyList()
    }

    // Auto Lock monitors activity and locks if idle
    fun userActivityDetected() {
        lastActiveTime = System.currentTimeMillis()
    }

    private fun startAutoLockMonitor() {
        autoLockJob?.cancel()
        autoLockJob = viewModelScope.launch {
            while (true) {
                delay(10000) // check every 10 seconds
                val delayMin = _autoLockDelay.value
                if (delayMin > 0 && _isUnlocked.value) {
                    val idleTimeMs = System.currentTimeMillis() - lastActiveTime
                    if (idleTimeMs >= delayMin * 60 * 1000L) {
                        lock()
                    }
                }
            }
        }
    }

    /**
     * Decrypt and Cache loaded items
     */
    private fun decryptAndCacheItems(rawList: List<VaultItem>) {
        if (!_isUnlocked.value) return

        val decrypted = mutableListOf<DecryptedVaultItem>()
        rawList.forEach { item ->
            val payload = SecurityManager.decrypt(item.encryptedData, item.iv)
            if (payload != null) {
                try {
                    val json = JSONObject(payload)
                    val map = mutableMapOf<String, String>()
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        map[key] = json.getString(key)
                    }
                    decrypted.add(DecryptedVaultItem(item, map))
                } catch (e: Exception) {
                    // Decryption failed for this specific item (possibly a real item in fake mode)
                    Log.e("VaultViewModel", "Failed to parse decrypted payload for ID ${item.id}")
                }
            }
        }
        _decryptedItems.value = decrypted
        calculateStats(decrypted)
    }

    private fun decryptDeletedItems(rawList: List<VaultItem>) {
        if (!_isUnlocked.value) return
        val decrypted = mutableListOf<DecryptedVaultItem>()
        rawList.forEach { item ->
            val payload = SecurityManager.decrypt(item.encryptedData, item.iv)
            if (payload != null) {
                try {
                    val json = JSONObject(payload)
                    val map = mutableMapOf<String, String>()
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        map[key] = json.getString(key)
                    }
                    decrypted.add(DecryptedVaultItem(item, map))
                } catch (e: Exception) {}
            }
        }
        _deletedItemsFlow.value = decrypted
    }

    private fun decryptArchivedItems(rawList: List<VaultItem>) {
        if (!_isUnlocked.value) return
        val decrypted = mutableListOf<DecryptedVaultItem>()
        rawList.forEach { item ->
            val payload = SecurityManager.decrypt(item.encryptedData, item.iv)
            if (payload != null) {
                try {
                    val json = JSONObject(payload)
                    val map = mutableMapOf<String, String>()
                    val keys = json.keys()
                    while (keys.hasNext()) {
                        val key = keys.next()
                        map[key] = json.getString(key)
                    }
                    decrypted.add(DecryptedVaultItem(item, map))
                } catch (e: Exception) {}
            }
        }
        _archivedItemsFlow.value = decrypted
    }

    private fun calculateStats(items: List<DecryptedVaultItem>) {
        var weakCount = 0
        var duplicateCount = 0
        val passwordCountMap = mutableMapOf<String, Int>()

        var totalPasswords = 0
        var totalNotes = 0
        var totalCards = 0
        var totalDocuments = 0

        items.forEach { decrypted ->
            when (decrypted.item.category) {
                "password" -> {
                    totalPasswords++
                    val pw = decrypted.fields["password"] ?: ""
                    if (pw.isNotEmpty()) {
                        val strength = calculatePasswordStrength(pw)
                        if (strength < 3) weakCount++
                        passwordCountMap[pw] = (passwordCountMap[pw] ?: 0) + 1
                    }
                }
                "note" -> totalNotes++
                "card" -> totalCards++
                "document" -> totalDocuments++
            }
        }

        duplicateCount = passwordCountMap.values.filter { it > 1 }.sum()

        // Security Score out of 100
        var score = 100
        if (totalPasswords > 0) {
            val weakRatio = weakCount.toFloat() / totalPasswords.toFloat()
            val duplicateRatio = duplicateCount.toFloat() / totalPasswords.toFloat()
            score -= (weakRatio * 50).toInt()
            score -= (duplicateRatio * 30).toInt()
            if (score < 10) score = 10
        }

        _dashboardStats.value = DashboardStats(
            totalPasswords = totalPasswords,
            totalNotes = totalNotes,
            totalCards = totalCards,
            totalDocuments = totalDocuments,
            weakPasswordCount = weakCount,
            duplicatePasswordCount = duplicateCount,
            securityScore = score
        )
    }

    /**
     * Copy value to clipboard with autodelete
     */
    fun copyToClipboard(label: String, text: String) {
        SecurityManager.copyToClipboard(getApplication(), label, text, _clipboardTimeout.value)
    }

    /**
     * Password Strength Evaluation: 0 (Weak) to 4 (Military-grade)
     */
    fun calculatePasswordStrength(password: String): Int {
        if (password.length < 4) return 0
        var score = 0
        if (password.length >= 8) score++
        if (password.length >= 14) score++
        if (password.any { it.isUpperCase() } && password.any { it.isLowerCase() }) score++
        if (password.any { it.isDigit() }) score++
        if (password.any { "!@#$%^&*()_+-=[]{}|;':\",./<>?".contains(it) }) score++
        
        return minOf(score, 4)
    }

    /**
     * Secure Password Generator
     */
    fun generatePassword(
        length: Int,
        useUpper: Boolean,
        useLower: Boolean,
        useNumbers: Boolean,
        useSymbols: Boolean,
        excludeSimilar: Boolean,
        excludeAmbiguous: Boolean
    ): String {
        val upperPool = "ABCDEFGHJKLMNPQRSTUVWXYZ" + if (excludeSimilar) "" else "IO"
        val lowerPool = "abcdefghijkmnopqrstuvwxyz" + if (excludeSimilar) "" else "l"
        val numberPool = "23456789" + if (excludeSimilar) "" else "01"
        val symbolPool = "@#\$%^&*()_+-=" + if (excludeAmbiguous) "" else "[]{}|;':\",./<>?\\~`"

        var pool = ""
        val mandatoryPool = mutableListOf<String>()

        if (useUpper) {
            pool += upperPool
            mandatoryPool.add(upperPool)
        }
        if (useLower) {
            pool += lowerPool
            mandatoryPool.add(lowerPool)
        }
        if (useNumbers) {
            pool += numberPool
            mandatoryPool.add(numberPool)
        }
        if (useSymbols) {
            pool += symbolPool
            mandatoryPool.add(symbolPool)
        }

        if (pool.isEmpty()) return ""

        val random = SecureRandom()
        val result = StringBuilder()

        // Place one mandatory char from each selected group to guarantee strength
        mandatoryPool.forEach { subPool ->
            result.append(subPool[random.nextInt(subPool.length)])
        }

        // Fill rest of the slots
        for (i in result.length until length) {
            result.append(pool[random.nextInt(pool.length)])
        }

        // Shuffle
        val chars = result.toString().toCharArray()
        for (i in chars.indices) {
            val j = random.nextInt(chars.size)
            val temp = chars[i]
            chars[i] = chars[j]
            chars[j] = temp
        }

        return String(chars)
    }

    fun generatePassphrase(wordsCount: Int): String {
        val wordList = listOf(
            "correct", "horse", "battery", "staple", "secure", "vault", "private", "digital",
            "crypto", "shadow", "cyber", "lock", "safety", "military", "shield", "portal",
            "cosmos", "whisper", "glacier", "phoenix", "falcon", "beacon", "titan", "matrix",
            "orbit", "radar", "signal", "quantum", "gravity", "nebula", "aurora", "comet"
        )
        val random = SecureRandom()
        val builder = StringBuilder()
        for (i in 0 until wordsCount) {
            builder.append(wordList[random.nextInt(wordList.size)])
            if (i < wordsCount - 1) builder.append("-")
        }
        return builder.toString()
    }

    /**
     * Database Operations
     */
    fun saveItem(
        id: Int = 0,
        category: String,
        title: String,
        subtitle: String = "",
        fields: Map<String, String>,
        isFavorite: Boolean = false,
        folder: String? = null,
        tags: List<String> = emptyList(),
        pinned: Boolean = false
    ) {
        viewModelScope.launch {
            try {
                // Convert fields Map to JSON string
                val json = JSONObject()
                fields.forEach { (k, v) -> json.put(k, v) }
                
                // Encrypt payload
                val payload = SecurityManager.encrypt(json.toString()) ?: return@launch
                
                val currentTagsStr = tags.joinToString(",")

                val item = VaultItem(
                    id = id,
                    category = category,
                    title = title,
                    subtitle = subtitle,
                    encryptedData = payload.cipherText,
                    iv = payload.iv,
                    isFavorite = isFavorite,
                    isArchived = false,
                    isDeleted = false,
                    createdAt = if (id == 0) System.currentTimeMillis() else System.currentTimeMillis(), // keep original or set now
                    updatedAt = System.currentTimeMillis(),
                    folder = folder,
                    tags = currentTagsStr,
                    pinned = pinned
                )
                repository.insertItem(item)
            } catch (e: Exception) {
                Log.e("VaultViewModel", "Failed to save item", e)
            }
        }
    }

    fun toggleFavorite(item: VaultItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(isFavorite = !item.isFavorite, updatedAt = System.currentTimeMillis()))
        }
    }

    fun togglePinned(item: VaultItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(pinned = !item.pinned, updatedAt = System.currentTimeMillis()))
        }
    }

    fun archiveItem(item: VaultItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(isArchived = true, isFavorite = false, pinned = false, updatedAt = System.currentTimeMillis()))
        }
    }

    fun restoreFromArchive(item: VaultItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(isArchived = false, updatedAt = System.currentTimeMillis()))
        }
    }

    fun trashItem(item: VaultItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(isDeleted = true, isFavorite = false, pinned = false, updatedAt = System.currentTimeMillis()))
        }
    }

    fun restoreFromTrash(item: VaultItem) {
        viewModelScope.launch {
            repository.updateItem(item.copy(isDeleted = false, updatedAt = System.currentTimeMillis()))
        }
    }

    fun permanentlyDeleteItem(item: VaultItem) {
        viewModelScope.launch {
            repository.deleteItem(item)
        }
    }

    fun emptyTrash() {
        viewModelScope.launch {
            repository.emptyTrash()
        }
    }

    /**
     * Search Management
     */
    fun updateSearchQuery(query: String) {
        _searchQuery.value = query
    }

    fun selectFolder(folder: String?) {
        _selectedFolder.value = folder
    }

    fun selectTag(tag: String?) {
        _selectedTag.value = tag
    }

    fun addRecentSearch(query: String) {
        if (query.trim().isEmpty()) return
        val current = _recentSearches.value.toMutableList()
        current.remove(query)
        current.add(0, query)
        if (current.size > 5) {
            current.removeAt(5)
        }
        _recentSearches.value = current
        saveSettings()
    }

    fun clearRecentSearches() {
        _recentSearches.value = emptyList()
        saveSettings()
    }

    /**
     * Backup & Restore / JSON & CSV Exports
     */
    fun exportBackupEncrypted(context: Context): File? {
        if (!_isUnlocked.value) return null
        try {
            val list = _rawItems.value
            val array = JSONArray()
            list.forEach { item ->
                val obj = JSONObject().apply {
                    put("category", item.category)
                    put("title", item.title)
                    put("subtitle", item.subtitle)
                    put("encryptedData", item.encryptedData)
                    put("iv", item.iv)
                    put("isFavorite", item.isFavorite)
                    put("isArchived", item.isArchived)
                    put("createdAt", item.createdAt)
                    put("folder", item.folder ?: "")
                    put("tags", item.tags)
                }
                array.put(obj)
            }
            
            // Encrypt the JSON dump using active AES-GCM
            val payload = SecurityManager.encrypt(array.toString()) ?: return null
            val exportObj = JSONObject().apply {
                put("vault9_encrypted_backup", true)
                put("payload", payload.cipherText)
                put("iv", payload.iv)
                put("timestamp", System.currentTimeMillis())
            }

            val file = File(context.cacheDir, "vault9_encrypted_backup_${System.currentTimeMillis()}.json")
            file.writeText(exportObj.toString())
            return file
        } catch (e: Exception) {
            Log.e("VaultViewModel", "Failed to export encrypted backup", e)
            return null
        }
    }

    fun importBackupEncrypted(jsonStr: String): Boolean {
        if (!_isUnlocked.value) return false
        try {
            val mainObj = JSONObject(jsonStr)
            if (!mainObj.has("vault9_encrypted_backup")) return false

            val cipherText = mainObj.getString("payload")
            val iv = mainObj.getString("iv")

            val decryptedPayload = SecurityManager.decrypt(cipherText, iv) ?: return false
            val array = JSONArray(decryptedPayload)

            viewModelScope.launch {
                for (i in 0 until array.length()) {
                    val obj = array.getJSONObject(i)
                    val item = VaultItem(
                        category = obj.getString("category"),
                        title = obj.getString("title"),
                        subtitle = obj.optString("subtitle", ""),
                        encryptedData = obj.getString("encryptedData"),
                        iv = obj.getString("iv"),
                        isFavorite = obj.optBoolean("isFavorite", false),
                        isArchived = obj.optBoolean("isArchived", false),
                        createdAt = obj.optLong("createdAt", System.currentTimeMillis()),
                        updatedAt = System.currentTimeMillis(),
                        folder = obj.optString("folder", null).takeIf { !it.isNullOrEmpty() },
                        tags = obj.optString("tags", "")
                    )
                    repository.insertItem(item)
                }
            }
            return true
        } catch (e: Exception) {
            Log.e("VaultViewModel", "Failed to import encrypted backup", e)
            return false
        }
    }

    fun exportToCSV(context: Context): File? {
        if (!_isUnlocked.value) return null
        try {
            val file = File(context.cacheDir, "vault9_export_${System.currentTimeMillis()}.csv")
            val writer = file.printWriter()
            
            // CSV Header
            writer.println("Category,Title,Username/Identity,SensitivePayloadInfo,Folder,Tags,Favorite")
            
            _decryptedItems.value.forEach { item ->
                // Render a safe text summary without compromising high security keys entirely,
                // or output clear fields for local backup CSV (which is what standard managers do)
                val category = item.item.category
                val title = item.item.title.replace(",", " ")
                val subtitle = item.item.subtitle.replace(",", " ")
                
                val details = StringBuilder()
                item.fields.forEach { (k, v) ->
                    if (k != "password" && k != "seed_phrase" && k != "private_key" && k != "cvv" && k != "atm_pin") {
                        details.append("$k: ${v.replace(",", " ")} | ")
                    } else {
                        details.append("$k: [ENCRYPTED_LOCKED] | ")
                    }
                }

                val folder = (item.item.folder ?: "").replace(",", " ")
                val tags = item.item.tags.replace(",", " ")
                val fav = if (item.item.isFavorite) "Yes" else "No"

                writer.println("$category,$title,$subtitle,${details.toString().trimEnd(' ', '|')},$folder,$tags,$fav")
            }
            writer.close()
            return file
        } catch (e: Exception) {
            Log.e("VaultViewModel", "Failed to export CSV", e)
            return null
        }
    }
}

data class DecryptedVaultItem(
    val item: VaultItem,
    val fields: Map<String, String>
)

data class DashboardStats(
    val totalPasswords: Int = 0,
    val totalNotes: Int = 0,
    val totalCards: Int = 0,
    val totalDocuments: Int = 0,
    val weakPasswordCount: Int = 0,
    val duplicatePasswordCount: Int = 0,
    val securityScore: Int = 100
)

data class IntruderLog(
    val timestamp: Long,
    val attemptCount: Int,
    val photoPath: String?
)
